"""Loopback-only, read-only HTML and JSON views of intake snapshots."""
from __future__ import annotations

import html
import json
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

from .intake import IntakeError, show

HOST = "127.0.0.1"
CSP = "default-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"


def _age(timestamp: str) -> str:
    value = datetime.fromisoformat(timestamp.replace("Z", "+00:00")).astimezone(timezone.utc)
    seconds = int((datetime.now(timezone.utc) - value).total_seconds())
    if seconds < 0:
        return "en el futuro"
    if seconds < 60:
        return f"hace {seconds} s"
    if seconds < 3600:
        return f"hace {seconds // 60} min"
    if seconds < 86400:
        return f"hace {seconds // 3600} h"
    return f"hace {seconds // 86400} d"


def _page(items: list[dict]) -> str:
    blocks = []
    for item in items:
        work_id = html.escape(item["id"], quote=True)
        title = html.escape(item["source"]["title"])
        brief = item["brief"]
        acceptance = "".join(f"<li>{html.escape(text)}</li>" for text in brief["acceptance"])
        observed = datetime.fromisoformat(item["observed_at"].replace("Z", "+00:00")).astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        updated = datetime.fromisoformat(item["updated_at"].replace("Z", "+00:00")).astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        blocks.append(f"<article><h2><a href='/work/{work_id}'>{title}</a></h2><p>{html.escape(item['category'])} · {html.escape(item['preparation'])}</p><p>Objetivo: {html.escape(brief['objective'])}</p><ul>{acceptance}</ul><p>Issue leída: {html.escape(observed)} ({_age(observed)}) · Ficha actualizada: {html.escape(updated)} ({_age(updated)})</p><p>Ejecución: no disponible en S01</p></article>")
    return "<!doctype html><html lang='es'><meta charset='utf-8'><meta name='viewport' content='width=device-width'><title>isSWF · trabajos</title><h1>Trabajos preparados</h1>" + ("".join(blocks) or "<p>No hay trabajos preparados.</p>") + "</html>"


def make_server(state: str, port: int = 8765) -> ThreadingHTTPServer:
    class Handler(BaseHTTPRequestHandler):
        def _reject(self, code: int, message: str) -> None:
            body = message.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", CSP)
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            expected_host = f"127.0.0.1:{self.server.server_port}"
            if self.headers.get("Host") != expected_host:
                self._reject(400, "Host no válido")
                return
            origin = self.headers.get("Origin")
            if origin:
                parsed_origin = urlsplit(origin)
                if parsed_origin.scheme != "http" or parsed_origin.netloc != expected_host or parsed_origin.path not in ("", "/") or parsed_origin.query or parsed_origin.fragment:
                    self._reject(403, "Origin no local")
                    return
            if self.headers.get("Sec-Fetch-Site", "").lower() == "cross-site":
                self._reject(403, "Solicitud cross-site rechazada")
                return
            path = self.path
            if not path.startswith("/") or "?" in path or "#" in path or "%" in path or "\\" in path or ".." in path:
                self._reject(404, "Ruta no válida")
                return
            try:
                if path == "/":
                    items = show(state)
                    body = _page(items).encode("utf-8")
                    content_type = "text/html; charset=utf-8"
                elif path == "/api/work":
                    body = json.dumps(show(state), ensure_ascii=False).encode("utf-8")
                    content_type = "application/json; charset=utf-8"
                elif path.startswith("/api/work/") and path.count("/") == 3:
                    item = show(state, path.removeprefix("/api/work/"))
                    body = json.dumps(item, ensure_ascii=False).encode("utf-8")
                    content_type = "application/json; charset=utf-8"
                elif path.startswith("/work/") and path.count("/") == 2:
                    item = show(state, path.removeprefix("/work/"))
                    body = _page([item]).encode("utf-8")
                    content_type = "text/html; charset=utf-8"
                else:
                    self._reject(404, "Ruta no encontrada")
                    return
            except IntakeError as exc:
                self._reject(503, f"Estado no disponible: {exc}")
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", CSP)
            self.send_header("X-Frame-Options", "DENY")
            self.end_headers()
            self.wfile.write(body)

        def do_HEAD(self) -> None:
            self._reject(405, "Solo se admite GET")

        def do_POST(self) -> None:
            self._reject(405, "Solo se admite GET")

        def do_PUT(self) -> None:
            self._reject(405, "Solo se admite GET")

        def do_DELETE(self) -> None:
            self._reject(405, "Solo se admite GET")

        def do_OPTIONS(self) -> None:
            self._reject(405, "Solo se admite GET")

        def log_message(self, fmt: str, *args: object) -> None:
            return

    return ThreadingHTTPServer((HOST, port), Handler)


def serve(state: str, port: int = 8765) -> None:
    server = make_server(state, port)
    try:
        print(f"Panel de solo lectura en http://127.0.0.1:{server.server_port}/")
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
